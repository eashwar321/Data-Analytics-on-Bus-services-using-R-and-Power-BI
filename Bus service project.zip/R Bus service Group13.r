# 
# Some of the functions are asis or derived from KevinRPan/handy package.
# https://rdrr.io/github/KevinRPan/handy/man/human_numbers.html

#require(plyr); require(scales)

human_numbers <- function(x = NULL, smbl =""){
  humanity <- function(y){             
    
    if (!is.na(y)){
      
      b <- round_any(abs(y) / 1e9, 0.1)
      m <- round_any(abs(y) / 1e6, 0.1)
      k <- round_any(abs(y) / 1e3, 0.1)
      
      if ( y >= 0 ){ 
        y_is_positive <- ""
      } else {
        y_is_positive <- "-"
      }
      
      if ( k < 1 ) {
        paste0(y_is_positive, smbl, y )
      } else if ( m < 1){
        paste0 (y_is_positive, smbl,  k , "k")
      } else if (b < 1){
        paste0 (y_is_positive, smbl, m ,"M")
      } else {
        paste0 (y_is_positive, smbl,  comma(b), "b")     
      }
    }
  }
  
  sapply(x,humanity)
}

#' Human versions of large currency numbers - extensible via smbl

human_gbp   <- function(x){human_numbers(x, smbl = "£")}
human_usd   <- function(x){human_numbers(x, smbl = "$")}
human_euro  <- function(x){human_numbers(x, smbl = "€")} 
human_num   <- function(x){human_numbers(x, smbl = "")} 

# if number is less than one then mupltiplied by 100 otherwise not. 
human_pct   <- function(x){if (x<1){x = 100*x }; 
  if(x<1) d=3 else if (x<10) d=2 else d=1;
  return(sprintf(paste0('%.',d,'f%%'), round(x,d))) }

hn.gbp  <- function(...){human_gbp(...)}
hn.usd  <- function(...){human_usd(...)}
hn.eur  <- function(...){human_euro(...)} 
hn.pct  <- function(...){human_pct(...)}
hn.num  <- function(...){human_numbers(...)}
hn      <- function(...){human_numbers(...)}
hnd     <- function(x,d){fmt(x,decimals =d)}

fancy_scientific <- function(l) {
  # turn in to character string in scientific notation
  l <- format(l, scientific = TRUE)
  
  l <- gsub("0e\\+00","0",l)
  
  # quote the part before the exponent to keep all the digits
  l <- gsub("^(.*)e", "'\\1'e", l)
  # turn the 'e+' into plotmath format
  l <- gsub("e", "%*%10^", l)
  # return this as an expression
  parse(text=l)
}

# format numeric matrices and data frames
fmt <- function(C, unit='', decimals=1, currency='') { 
  #if (is.numeric(C)) {C = as.character(C)}
  str = format(round(C,decimals), big.mark=",", nsmall = decimals, trim=TRUE, justify = "right" )
  if (is.matrix(C) | is.data.frame(C)){
    for (i in 1:nrow(C))
      for (j in 1:ncol(C)) 
        str[i,j] = paste0(currency, str[i,j], unit);
  }
  else {str  = paste0(currency, str, unit); }
  return(str)
}

# simple display functions
disp <- function(..., sep='') { cat( paste(..., sep=sep, collapse=sep), "\n") }
printf <- function(...) {cat(sprintf(...))}

# y = actual value, yh = modelled value
mape  <- function(y,yh) { # mean absolute percentage error
  I = actual !=0;   pe = mean(abs((y[I]-yh[I])/y[I]));
  if (sum(actual==0)>0) {warning(sprintf('%i values are zero\n',sum(actual==0)))}
  return (pe)
}
rmse     <- function(y,yh) {sqrt(mean((y-yh)^2))} # root mean squared error
mae      <- function(y,yh) {mean(abs(y-yh))}
frmse    <- function(y,yh) {fmt(rmse(y,yh))} 
fmape    <- function(y,yh) {fmt(mape(y,yh)*100,'%')}
fmae     <- function(y,yh) {fmt(mae(y,yh))} 

showErrors <- function(y,yh){
  disp('rmse=',frmse(y,yh),', mae=',fmae(y,yh),', mape=',fmape(y,yh));
  plot(y, yh, pch='.', cex=8, col = 'black', ylab = "modelled", xlab = "observed",main="LR"); 
  abline(0,1, lwd=3, col='red')
}

# Initialise
cat('\14'); rm(list=ls());graphics.off(); 
# source('easyDBaccess.R'); saveRDS(df, "routes_aggr.rds")
library(pacman); p_load(tidyverse)
rmse  <- function(y,yh) {sqrt(mean((y-yh)^2))}
mape  <- function(y,yh) {mean(abs((y-yh)/y))} # y=actual value, yh=modelled value (note issue when y is zero!)
frmse <- function(y,yh) {fmt(rmse(y,yh))}
fmape <- function(y,yh) {fmt(mape(y,yh)*100,'%')}
derr  <- function(y,yh,model="") {disp(model,'rmse=',frmse(y,yh),', mape=',fmape(y,yh))}
aplot <- function(y,yh, main="") {
  plot(y, yh, pch='.', cex=8, col = 'black', 
       ylab = "modelled", xlab = "observed",main=main); 
  abline(0,1, lwd=3, col='red');
}

# prepare data (for a specific group)
S = readRDS('routes_aggr.rds')
T = S %>% filter(peak == "Peak", weekday == "Weekday")
U = T %>% dplyr::select(-c(bus_operator, route, peak, weekday, passengers_sd))

# explore data
p_load(GGally)
ggpairs(U) 
# gain insights >> why is the households correlation not larger!?
# >> what is the definition

# define train (and test) rows
nr = length(unique(T$route)); nt=floor(.7*nr);
set.seed(1); train = sample(1:nr, nt);
# what happens if 80% are used, or a different seed is used?

## A few default models: LM, LR, DT and RF
# linear model
m1 <- lm ( passengers_avg~., data = U[train,])
yh  = predict(m1, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"LM: "); aplot(y,yh,"LM")

# linear regression (normal equation)
p_load(MASS)
ya = U$passengers_avg[train]
pX = U %>% dplyr::select(-c(passengers_avg))
X = as.matrix( pX[train,]) 
b = ginv(t(X) %*% X) %*% t(X) %*% ya

y = U$passengers_avg[-train]
Xt = as.matrix( pX[-train,]) 
yh = Xt %*% b
derr(y,yh,"LR: "); aplot(y,yh,"LR")
# in theory this should be the same as LM, 
# but the underlying calculations differ

# decision tree
p_load(tree)
dt = tree(passengers_avg~., data = U, subset=train)

yh  = predict(dt, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Decision Tree: "); 
aplot(y,yh,"Decsion Tree")

# random forest
p_load(randomForest)
set.seed(1); # fix random number
rf = randomForest(formula = passengers_avg~., data = U, subset=train, importance = TRUE)

yh  = predict(rf, newdata=U[-train,])
y   = U$passengers_avg[-train]

derr(y,yh,"RF: "); aplot(y,yh,"RF")

I = importance(rf);I = I[order(-I[,1]),]
varImpPlot(rf)

#Neural Network
p_load(neuralnet)
nn=neuralnet(passengers_avg~.,data=U,hidden=3,act.fct="logistic",linear.output=FALSE)
yh  = predict(nn, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Neural Network: "); aplot(y,yh,"Neural Network")

# Support vector machine(Linear)
svm.r = e1071::svm(formula = passengers_avg~., data = U[train,],
                   type = 'eps-regression', 
                   kernel = 'linear') 

yh  = predict(svm.r, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"SVM Linear: "); aplot(y,yh,"SVM Linear")


# Support vector machine(Polynomial)
svm.r = e1071::svm(formula = passengers_avg~., data = U[train,],
                   type = 'eps-regression', 
                   kernel = 'polynomial') 

yh  = predict(svm.r, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"SVM Polynomial: "); aplot(y,yh,"SVM Polynomial")


#80%,20%
nr = length(unique(T$route)); nt=floor(.8*nr);
set.seed(1); train = sample(1:nr, nt);
# what happens if 80% are used, or a different seed is used?

## A few default models: LM, LR, DT and RF
# linear model
m1 <- lm ( passengers_avg~., data = U[train,])
yh  = predict(m1, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Linear Model: ");
aplot(y,yh,"Linear Model")

# linear regression (normal equation)
p_load(MASS)
ya = U$passengers_avg[train]
pX = U %>% dplyr::select(-c(passengers_avg))
X = as.matrix( pX[train,]) 
b = ginv(t(X) %*% X) %*% t(X) %*% ya

y = U$passengers_avg[-train]
Xt = as.matrix( pX[-train,]) 
yh = Xt %*% b
derr(y,yh,"Linear Regression: ");
aplot(y,yh,"Linear Regression")
# in theory this should be the same as LM, 
# but the underlying calculations differ

# decision tree
p_load(tree)
dt = tree(passengers_avg~., data = U, subset=train)

yh  = predict(dt, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Decision Tree: "); 
aplot(y,yh,"Decsion Tree")

# random forest
p_load(randomForest)
set.seed(1); # fix random number
rf = randomForest(formula = passengers_avg~., data = U, subset=train, importance = TRUE)

yh  = predict(rf, newdata=U[-train,])
y   = U$passengers_avg[-train]

derr(y,yh,"Random Forest: "); aplot(y,yh,"Random Forest")

I = importance(rf);I = I[order(-I[,1]),]
varImpPlot(rf)

#Neural Network
p_load(neuralnet)
nn=neuralnet(passengers_avg~.,data=U,hidden=3,act.fct="logistic",linear.output=FALSE)
yh  = predict(nn, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Neural Network: "); aplot(y,yh,"Neural Network")

# Support vector machine(Linear)
svm.r = e1071::svm(formula = passengers_avg~., data = U[train,],
                   type = 'eps-regression', 
                   kernel = 'linear') 

yh  = predict(svm.r, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"SVM Linear: "); aplot(y,yh,"SVM Linear")


# Support vector machine(Polynomial)
svm.r = e1071::svm(formula = passengers_avg~., data = U[train,],
                   type = 'eps-regression', 
                   kernel = 'polynomial') 

yh  = predict(svm.r, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"SVM Polynomial: "); aplot(y,yh,"SVM Polynomial")

#75%,25%
nr = length(unique(T$route)); nt=floor(.75*nr);
set.seed(1); train = sample(1:nr, nt);
# what happens if 90% are used, or a different seed is used?

## A few default models: LM, LR, DT and RF
# linear model
m1 <- lm ( passengers_avg~., data = U[train,])
yh  = predict(m1, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Linear Model: ");
aplot(y,yh,"Linear Model")

# linear regression (normal equation)
p_load(MASS)
ya = U$passengers_avg[train]
pX = U %>% dplyr::select(-c(passengers_avg))
X = as.matrix( pX[train,]) 
b = ginv(t(X) %*% X) %*% t(X) %*% ya

y = U$passengers_avg[-train]
Xt = as.matrix( pX[-train,]) 
yh = Xt %*% b
derr(y,yh,"Linear Regression: ");
aplot(y,yh,"Linear Regression")
# in theory this should be the same as LM, 
# but the underlying calculations differ

# decision tree
p_load(tree)
dt = tree(passengers_avg~., data = U, subset=train)

yh  = predict(dt, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Decision Tree: "); 
aplot(y,yh,"Decsion Tree")

# random forest
p_load(randomForest)
set.seed(1); # fix random number
rf = randomForest(formula = passengers_avg~., data = U, subset=train, importance = TRUE)

yh  = predict(rf, newdata=U[-train,])
y   = U$passengers_avg[-train]

derr(y,yh,"Random Forest: "); aplot(y,yh,"Random Forest")

I = importance(rf);I = I[order(-I[,1]),]
varImpPlot(rf)

#Neural Network
p_load(neuralnet)
nn=neuralnet(passengers_avg~.,data=U,hidden=3,act.fct="logistic",linear.output=FALSE)
yh  = predict(nn, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"Neural Network: "); aplot(y,yh,"Neural Network")

# Support vector machine(Linear)
svm.r = e1071::svm(formula = passengers_avg~., data = U[train,],
                   type = 'eps-regression', 
                   kernel = 'linear') 

yh  = predict(svm.r, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"SVM Linear: "); aplot(y,yh,"SVM Linear")

# Support vector machine(Polynomial)
svm.r = e1071::svm(formula = passengers_avg~., data = U[train,],
                   type = 'eps-regression', 
                   kernel = 'polynomial') 

yh  = predict(svm.r, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"SVM Polynomial: "); aplot(y,yh,"SVM Polynomial")


str(S)
sapply(S,FUN = function(x) sum(is.na(x)))
S %>% filter(is.na(passengers_sd))
S %>% group_by(bus_operator,weekday,peak) %>% 
  summarise(AVG_passengers = round(mean(passengers_avg))) %>% 
  ggplot(aes(x=bus_operator, y=AVG_passengers, fill=weekday,color=weekday))+
  geom_bar(stat = 'identity',position=position_dodge()) + 
  geom_text(aes(label=round(AVG_passengers,2)), position=position_dodge(width=0.9), vjust=-0.25)

#DAILY TABLE
# ARIMA analysis
library(forecast)

# Timeseries data
ts_ARMA <- ARMA %>% group_by(sdate) %>% 
  summarise(Total_passengers = sum(passengers))
ts_ARMA <- ts(ts_ARMA$Total_passengers)
